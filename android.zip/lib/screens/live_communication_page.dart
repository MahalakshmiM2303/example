import 'package:flutter/material.dart';

class LiveCommunication extends StatefulWidget {
  @override
  _LiveCommunicationState createState() => _LiveCommunicationState();
}

class _LiveCommunicationState extends State<LiveCommunication> {
  // Predefined queries and responses related to disaster safety
  final Map<String, String> disasterSafetyFaq = {
    "hello": "Hi,How can  I help u",
    "hey": "Hi,How can  I help u",
    "hi": "Hi,How can  I help u",
    "What should I do during an earthquake?":
        "Drop to your hands and knees, cover your head and neck, and hold on until the shaking stops.",
    "How can I prepare for a flood?":
        "Ensure your home is on high ground, store important documents in waterproof containers, and have an evacuation plan.",
    "What items should I include in an emergency kit?":
        "Water, non-perishable food, flashlight, batteries, first aid kit, medications, and important documents.",
    "How can I stay safe during a wildfire?":
        "Stay indoors, keep windows and doors closed, and avoid using electrical appliances until the fire is under control.",
    "What to do if I'm caught in a landslide?":
        "Move quickly to higher ground, avoid valleys, and seek shelter in a sturdy structure if possible.",
    "How can I protect my home from a hurricane?":
        "Secure windows with storm shutters, reinforce doors, and evacuate if authorities advise it.",
    "What should I do if I smell gas after an earthquake?":
        "Evacuate the area immediately and call your gas company or emergency services.",
    "How do I make an evacuation plan?":
        "Identify multiple exits, designate a meeting point, and ensure all family members know the plan.",
    "How to find a safe zone during a natural disaster?":
        "Look for local government guidance, follow evacuation routes, and head towards designated shelters or safe zones.",
    "What to do during a tornado?":
        "Seek shelter in a basement or interior room on the lowest floor, away from windows.",
    "How can I get updates during a disaster?":
        "Use a battery-operated radio, a weather app, or listen to emergency services for updates.",
    "What are the signs of a tsunami?":
        "A sudden drop in ocean water, followed by a loud roar. Move to higher ground immediately.",
    "How can I assist people with disabilities during a disaster?":
        "Help them evacuate to safety, ensure they have necessary medical supplies, and stay calm.",
    "What should I do if my phone is low on battery during a disaster?":
        "Use power-saving mode, conserve battery by turning off non-essential apps, and find charging stations.",
    "How can I stay safe during a cyclone?":
        "Stay indoors, close windows securely, and keep an emergency kit ready.",
    "What to do if a cyclone is approaching?":
        "Evacuate to a cyclone shelter if advised, and stay updated via radio or news.",
    "How can I prevent injuries during a disaster?":
        "Stay calm, follow safety guidelines, use protective gear if needed, and avoid dangerous areas."
  };

  // List to hold the chat messages
  List<Widget> chatMessages = [];

  // Text Controller for input field
  TextEditingController _controller = TextEditingController();

  // Method to handle query and provide a response
  void handleQuery(String query) {
    String response = disasterSafetyFaq[query] ??
        "Sorry, I don't have information on that query.";
    setState(() {
      chatMessages.add(ChatMessage(message: query, isUser: true));
      chatMessages.add(ChatMessage(message: response, isUser: false));
    });
    _controller.clear(); // Clear the input field
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Live Communication'),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView(
              children: chatMessages,
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: InputDecoration(
                      hintText: "Ask a question...",
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                    ),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.send),
                  onPressed: () {
                    String query = _controller.text.trim();
                    if (query.isNotEmpty) {
                      handleQuery(query);
                    }
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// Widget to represent a chat message
class ChatMessage extends StatelessWidget {
  final String message;
  final bool isUser;

  ChatMessage({required this.message, required this.isUser});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(10.0),
      margin: EdgeInsets.symmetric(vertical: 5.0, horizontal: 10.0),
      decoration: BoxDecoration(
        color: isUser ? Colors.blue : Colors.grey[300],
        borderRadius: BorderRadius.circular(10.0),
      ),
      child: Text(
        message,
        style: TextStyle(color: isUser ? Colors.white : Colors.black),
      ),
    );
  }
}
