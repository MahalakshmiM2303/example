import 'package:flutter/material.dart';

class PreparednessTipsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Preparedness Tips'),
      ),
      body: Center(
        child: Text(
          'This is the Preparedness Tips page.',
          style: TextStyle(fontSize: 18),
        ),
      ),
    );
  }
}
