import 'package:flutter/material.dart';

class SafeZonesPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Safe Zones'),
      ),
      body: Center(
        child: Text(
          'This is the Safe Zones page.',
          style: TextStyle(fontSize: 18),
        ),
      ),
    );
  }
}


