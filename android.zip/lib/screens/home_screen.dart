import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'notification_page.dart';
import 'safe_zones_page.dart';
import 'live_communication_page.dart';
import 'preparedness_tips_page.dart';
import 'my_requests_page.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String _disasterMessage = "Fetching weather data...";
  String _apiKey =
      "039449092a60afc95c0f836c5580f57e"; // Replace with your OpenWeatherMap API key
  String _city = "Chennai"; // Replace with your city name
  double _temperature = 0.0;
  String _weatherCondition = "";

  @override
  void initState() {
    super.initState();
    fetchWeatherData();
  }

  Future<void> fetchWeatherData() async {
    try {
      final url =
          "https://api.openweathermap.org/data/2.5/weather?q=$_city&appid=$_apiKey&units=metric";
      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final double temperature = data["main"]["temp"];
        final String weather = data["weather"][0]["main"];
        final String weatherDescription = data["weather"][0]["description"];

        setState(() {
          _temperature = temperature;
          _weatherCondition = weather;

          // Set disaster message based on detailed weather conditions
          if (weatherDescription.contains("moderate rain")) {
            _disasterMessage =
                "Moderate rain (${_temperature.toStringAsFixed(1)}°C). Avoid unnecessary travel and stay prepared for potential delays";
          } else if (weatherDescription.contains("heavy rain")) {
            _disasterMessage =
                "Heavy rain (${_temperature.toStringAsFixed(1)}°C). Stay safe, stay indoors!";
          } else if (weather.contains("Rain")) {
            _disasterMessage =
                "Light rain (${_temperature.toStringAsFixed(1)}°C). Carry an umbrella and drive cautiously; roads might be slippery";
          } else if (weather.contains("Clouds")) {
            _disasterMessage =
                "Cloudy day (${_temperature.toStringAsFixed(1)}°C). A great time to go outdoors.";
          } else if (weather.contains("Clear")) {
            _disasterMessage =
                "Sunny day (${_temperature.toStringAsFixed(1)}°C). Enjoy the sunshine! Don’t forget sunscreen and stay hydrated";
          } else if (weather.contains("Fog")) {
            _disasterMessage =
                "Foggy conditions (${_temperature.toStringAsFixed(1)}°C). Drive with caution ;use fog lights for better visibility.";
          } else if (data["main"]["humidity"] > 80) {
            _disasterMessage =
                "High humidity (${_temperature.toStringAsFixed(1)}°C). Stay cool, hydrated, and avoid strenuous activities outdoors.";
          } else {
            _disasterMessage =
                "Weather: $weather (${_temperature.toStringAsFixed(1)}°C). Stay safe!";
          }
        });
      } else {
        setState(() {
          _disasterMessage = "Unable to fetch weather data. Try again later.";
        });
      }
    } catch (error) {
      setState(() {
        _disasterMessage =
            "Error fetching weather data. Check your connection.";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Rescue Hub'),
        actions: [
          IconButton(
            icon: Icon(
              Icons.notifications,
              color: Colors.blue, // Notification icon in blue
            ),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => NotificationPage()),
              );
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // SOS Button
              Center(
                child: ElevatedButton(
                  onPressed: () {
                    // Add SOS action here
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red,
                    padding: EdgeInsets.symmetric(vertical: 20, horizontal: 80),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: Text(
                    'SOS Request Help',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
              SizedBox(height: 20),
              // Disaster Alerts Section
              Text(
                'Disaster Alerts',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 10),
              Container(
                height: 100,
                decoration: BoxDecoration(
                  color: Colors.blue[50],
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Center(
                  child: Text(
                    _disasterMessage,
                    style: TextStyle(fontSize: 16),
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
              SizedBox(height: 20),
              // Locate Safe Zones and Live Communication
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _buildFeatureCard(
                    context,
                    title: 'Locate Safe Zones',
                    icon: Icons.location_on,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => SafeZonesPage()),
                      );
                    },
                  ),
                  _buildFeatureCard(
                    context,
                    title: 'Live Communication',
                    icon: Icons.chat,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => LiveCommunication()),
                      );
                    },
                  ),
                ],
              ),
              SizedBox(height: 20),
              // Preparedness Tips and My Requests
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _buildFeatureCard(
                    context,
                    title: 'Preparedness Tips',
                    icon: Icons.info,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => PreparednessTipsPage()),
                      );
                    },
                  ),
                  _buildFeatureCard(
                    context,
                    title: 'My Requests',
                    icon: Icons.history,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => MyRequestsPage()),
                      );
                    },
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Reusable Feature Card Widget
  Widget _buildFeatureCard(BuildContext context,
      {required String title,
      required IconData icon,
      required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: MediaQuery.of(context).size.width / 2.5,
        padding: EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.blue[50],
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          children: [
            Icon(icon, size: 40, color: Colors.blue),
            SizedBox(height: 10),
            Text(
              title,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
