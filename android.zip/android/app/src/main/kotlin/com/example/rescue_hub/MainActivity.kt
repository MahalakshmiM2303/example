package com.example.rescue_hub

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
